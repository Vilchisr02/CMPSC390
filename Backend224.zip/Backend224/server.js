const express = require('express');
const path = require('path');
const authRoutes = require('./auth'); // Import the auth routes
const mysql = require('mysql2');
const app = express();
const PORT = 3000;

// Middleware to parse JSON bodies
app.use(express.json());

app.use(express.static(path.join(__dirname, '../frontend')));

//Create SQL connection
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'LucidCharm2!',
    database: 'eCommerceDB',
});

const promisePool = pool.promise();

// Use the authentication routes
app.use('/auth', authRoutes);

app.get('/', (req, res) => {
    res.send("Hello World!");
});

app.get('/api/user', (req, res) => {
    const user = {
        Fname: "John",
        Lname: "Doe",
        Username: "jDoe01",
        Email: "johndoe@example.com",
        Address: "1234 Elm Street, Springfield, IL 62701",
        PhoneNumber: "1234567890"
    };
    res.json(user);
});

//Message if connected to SQL or not
promisePool.getConnection()
    .then(() => {
        console.log("MySQL Connection Successful");
    })
    .catch((error) => {
        console.error("MySQL Connection Failed", error);
    });


app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});


