const mysql = require('mysql2');
require('dotenv').config();

const db = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'LucidCharm2!',
    database: process.env.DB_NAME || 'eCommerceDB',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,

});

const promisePool = db.promise();

module.exports = promisePool;
